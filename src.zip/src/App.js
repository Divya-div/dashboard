import React, { useEffect, useState } from 'react';
import './App.css';
import axios from 'axios';
import { Container, Grid } from '@material-ui/core';
import { MapContainer, TileLayer, Marker, Popup} from 'react-leaflet';

function App() {
  
 const [activeCases, setActiveCases] = React.useState([],{});
 const [totalCases, setTotalCases] = React.useState({});

async function getcoronaCases() {
  const {data} = await axios.get('https://corona.lmao.ninja/v2/countries');
  const value = await axios.get('https://disease.sh/v3/covid-19/all');
   console.log("res", data);
   console.log('totalValue', value);
  setActiveCases(data.slice(0,99));
  setTotalCases(value.data);
}
useEffect( () => 
  getcoronaCases(),
 []);

  return (
    <div>
    <MapContainer
    className="markercluster-map"
    center={[0, 0]}
    zoom={3}
    maxZoom={18}
  >
    <TileLayer
      url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      attribution='&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
    />
    {activeCases.map((cases) => (
      <Marker key={cases.countryInfo._id} 
      position = {[cases.countryInfo.lat, cases.countryInfo.long]}
      onClick={() =>{
        setActiveCases(cases);
      }}
      >
        <Popup 
        key ={cases.countryInfo._id}
        position = {[cases.countryInfo.lat, cases.countryInfo.long]}
        >
        <div>
          <h2><img src={[cases.countryInfo.flag]} style={{width:'20px',height:'20px',padding:"5px 5px 0px 5px",marginBottom:'-5px'}} />{cases.country}</h2>
          <ul className="details">
            <li><strong>Confirmed : </strong>{cases?.cases?.toLocaleString()}</li>
            <li><strong>Deaths : </strong>{cases?.deaths?.toLocaleString()}</li>
            <li><strong>Recovered : </strong>{cases?.recovered?.toLocaleString()}</li>
          </ul>
        </div>
        </Popup>
      </Marker>
    
  ))}
  
  </MapContainer>
  <Container style={{background:'#000',padding:'0'}}>
      <Grid container className="dashboard">
      <Grid item md={4} sm={6} xs={12}>
      <h2>{totalCases?.tests?.toLocaleString()}</h2>
        <p>Total Tests</p>
        <h4>{totalCases?.testsPerOneMillion?.toLocaleString()}</h4>
        <p><small>Per 1 Million</small></p>
      </Grid>
      <Grid item md={4} sm={6} xs={12}>
        <h2>{totalCases?.cases?.toLocaleString()}</h2>
        <p>Total Cases</p>
        <h4>{totalCases?.casesPerOneMillion?.toLocaleString()}</h4>
        <p><small>Per 1 Million</small></p>
      </Grid>
      <Grid item md={4} sm={6} xs={12}>
        <h2>{totalCases?.deaths?.toLocaleString()}</h2>
        <p>Total Deaths</p>
        <h4>{totalCases?.deathsPerOneMillion?.toLocaleString()}</h4>
        <p><small>Per 1 Million</small></p>
      </Grid>
      </Grid>
    <Grid container className="dashboard">
      <Grid item md={4} sm={6} xs={12}>
      <h2>{totalCases?.active?.toLocaleString()}</h2>
        <p>Active</p>
      </Grid>
      <Grid item md={4} sm={6} xs={12}>
      <h2>{totalCases?.critical?.toLocaleString()}</h2>
        <p>Critical</p>
      </Grid>
      <Grid item md={4} sm={6} xs={12}>
      <h2>{totalCases?.recovered?.toLocaleString()}</h2>
        <p>Recovered</p>
      </Grid>
    </Grid>
    <Grid container className="dashboard">
      <Grid item md={12}>
        <p>Last updated : {new Intl.DateTimeFormat('en-GB', { dateStyle: 'full', timeStyle: 'short' }).format(totalCases?.updated)} </p>
      </Grid>
    </Grid>
  </Container>
  </div>
  
  
  

    // <div className="App">
    //   <header className="App-header">
    //     <img src={logo} className="App-logo" alt="logo" />
    //     <p>
    //       Edit <code>src/App.js</code> and save to reload.
    //     </p>
    //     <a
    //       className="App-link"
    //       href="https://reactjs.org"
    //       target="_blank"
    //       rel="noopener noreferrer"
    //     >
    //       Learn React
    //     </a>
    //   </header>
    // </div>
  );
}

export default App;
